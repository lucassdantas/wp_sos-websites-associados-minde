<?php
defined('ABSPATH') or die();

function csc_shortcode_associados($atts) {
    $posts_por_pagina = 6;
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    $args = [
        'post_type'      => 'posts_associados',
        'posts_per_page' => $posts_por_pagina,
        'paged'          => $paged
    ];
    $query = new WP_Query($args);

    ob_start();

    if ($query->have_posts()) {
        echo '<div class="elementor-container">';
        echo '<div class="elementor-row">';

        while ($query->have_posts()) {
            $query->the_post();

            $thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'medium') ?: 'https://via.placeholder.com/300';
            $post_slug = get_post_field('post_name', get_the_ID());

            echo '<div class="elementor-column" style="width: 100%; padding: 15px;">';
            echo '  <div class="elementor-card" style="width: 100%; border: 1px solid #ddd; padding: 15px; border-radius: 8px; box-shadow: 2px 2px 10px rgba(0,0,0,0.1); text-align: center;">';
            echo '      <img src="' . esc_url($thumbnail) . '" alt="' . get_the_title() . '" style="width: 100%; border-radius: 8px;">';
            echo '      <h3 style="margin-top: 10px;"><a href="' . esc_url(home_url('/posts-associados/' . $post_slug)) . '">' . get_the_title() . '</a></h3>';
            echo '      <p>' . get_the_excerpt() . '</p>';
            echo '      <a href="' . esc_url(home_url('/posts-associados/' . $post_slug)) . '" style="display: inline-block; margin-top: 10px; padding: 8px 12px; background: #009600; color: #fff; text-decoration: none; border-radius: 5px;">Ler mais</a>';
            echo '  </div>';
            echo '</div>';
        }

        echo '</div>'; // Fechar elementor-row
        echo '</div>'; // Fechar elementor-container

        echo '<div style="text-align: center; margin-top: 20px;">';
        echo paginate_links([
            'total'   => $query->max_num_pages,
            'current' => $paged,
            'prev_text' => '« Anterior',
            'next_text' => 'Próximo »',
        ]);
        echo '</div>';
    } else {
        echo '<p>Nenhum post encontrado.</p>';
    }

    wp_reset_postdata();

    return ob_get_clean();
}

add_shortcode('associados_posts', 'csc_shortcode_associados');
