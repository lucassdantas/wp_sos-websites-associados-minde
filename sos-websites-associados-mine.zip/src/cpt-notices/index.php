<?php 

//AMDG