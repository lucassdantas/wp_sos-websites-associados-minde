<?php 
//amdg